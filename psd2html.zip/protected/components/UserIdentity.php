<?php

/**
 * UserIdentity represents the data needed to identity a user.
 * It contains the authentication method that checks if the provided
 * data can identity the user.
 */
class UserIdentity extends CUserIdentity {

    /**
     * Authenticates a user.
     * The example implementation makes sure if the username and password
     * are both 'demo'.
     * In practical applications, this should be changed to authenticate
     * against some persistent user identity storage (e.g. database).
     * @return boolean whether authentication succeeds.
     */
    public function authenticate() {
        if ($this->username == "")
            $this->errorCode = self::ERROR_USERNAME_INVALID;
        elseif ($this->password == "")
            $this->errorCode = self::ERROR_PASSWORD_INVALID;
        else
            $this->errorCode = self::ERROR_NONE;
        return !$this->errorCode;
    }

    public function SendMail($to, $subject, $mailer, $data = array()) {
        Yii::import('ext.yii-mail.YiiMailMessage');
        $message = new YiiMailMessage;
        $message->view = $mailer;
        $message->setBody($data, 'text/html');
        $message->subject = $subject;
        $message->addTo($to);
        $message->from = Yii::app()->params['adminEmail'];
        Yii::app()->mail->send($message);
    }

    public function SendCustomMail($to, $subject, $text) {
        /*Yii::import('ext.yii-mail.YiiMailMessage');
        $message = new YiiMailMessage;
        $message->setBody($text, 'text/html');
        $message->subject = $subject;
        $message->setTo($to);
        $message->from = Yii::app()->params['adminEmail'];
        Yii::app()->mail->send($message);*/
        
        Yii::import('ext.phpmailer.JPhpMailer');
        $mail = new JPhpMailer;
        $mail->IsSMTP();
        $mail->Host = 'smtp.yandex.ru:465';
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = "ssl";
        $mail->Username = 'ticket@payway.ug';
        $mail->Password = 'ACYeBL0v';
        $mail->SetFrom(Yii::app()->params['adminEmail'],'Payway Ticket System');
        $mail->Subject = $subject;
        $mail->AltBody = 'To view the message, please use an HTML compatible email viewer!';
        $mail->MsgHTML($text);
        $mail->AddAddress($to);
        $mail->Send();
        
    }

   

}