<?php

class Utils {

    public static function getListOfControllers($flag = TRUE) {

        $appControllerPath = Yii::getPathOfAlias('application.controllers');

        //checking existence of controllers directory
        if (is_dir($appControllerPath)) {
            $fileLists = CFileHelper::findFiles($appControllerPath);
        }

        $controllerName = array();
        foreach ($fileLists as $controllerPath) {
            //getting controller name like e.g. 'siteController.php' 
            $name = substr($controllerPath, strrpos($controllerPath, DIRECTORY_SEPARATOR) + 1, -4);

            $name = str_replace('Controller', '', $name);

            if ($name == 'Auth') {
                if ($flag != TRUE) {
                    $controllerName[$name] = $name;
                }
            } else {
                $controllerName[$name] = $name;
            }
        }
        return $controllerName;
    }

    public static function getRandomPassword($length = 8) {

        $characters = '123456789abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ';

        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }

        return $randomString;
    }

    public static function getBaseUrl() {        
        if ($_SERVER['SERVER_NAME'] == 'localhost') {
            $base_url = 'http://localhost' . Yii::app()->baseUrl;
        } else {
            $base_url = 'http://' . Yii::app()->baseUrl;
        }
        return $base_url;
    }

    private function Encryption_Key() {
        $string = 'd0a7e7997b6d5fcd55f4b5c32611b87cd923e88837b63bf2941ef819dc8ca282';
        return $string;
    }

    private function mc_encrypt($encrypt, $key) {
        $encrypt = serialize($encrypt);
        $iv = mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_CBC), MCRYPT_DEV_URANDOM);
        $key = pack('H*', $key);
        $mac = hash_hmac('sha256', $encrypt, substr(bin2hex($key), -32));
        $passcrypt = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $key, $encrypt . $mac, MCRYPT_MODE_CBC, $iv);
        $encoded = base64_encode($passcrypt) . '|' . base64_encode($iv);
        return $encoded;
    }

    private function mc_decrypt($decrypt, $key) {
        $decrypt = explode('|', $decrypt . '|');
        $decoded = base64_decode($decrypt[0]);
        $iv = base64_decode($decrypt[1]);
        if (strlen($iv) !== mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_CBC)) {
            return false;
        }
        $key = pack('H*', $key);
        $decrypted = trim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $key, $decoded, MCRYPT_MODE_CBC, $iv));
        $mac = substr($decrypted, -64);
        $decrypted = substr($decrypted, 0, -64);
        $calcmac = hash_hmac('sha256', $decrypted, substr(bin2hex($key), -32));
        if ($calcmac !== $mac) {
            return false;
        }
        $decrypted = unserialize($decrypted);
        return $decrypted;
    }

    function passwordEncrypt($password) {
        return $this->mc_encrypt($password, $this->Encryption_Key());
    }

    function passwordDecrypt($password) {
        return $this->mc_decrypt($password, $this->Encryption_Key());
    }

}
