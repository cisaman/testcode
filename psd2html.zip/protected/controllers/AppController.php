<?php

class AppController extends Controller {

    public function actionAddOrder() {
        
    }

    public function actionAddUser() {

        $model = new Users;
        if (isset($_REQUEST['user_name']) && isset($_REQUEST['user_email'])) {
            $model->user_created_by_id = 0;
            $model->user_email = $_REQUEST['user_email'];
            $model->user_name = $_REQUEST['user_name'];
            $model->user_role_type = 5;
            $model->user_department_id = 0;
            $passwod = Utils::getRandomPassword();
            $model->user_password = md5($passwod);

            $userdata['user_name'] = $model->user_name;
            $userdata['user_email'] = $model->user_email;
            $userdata['user_password'] = $passwod;
            $userdata['login_url'] = Utils::getBaseUrl() . "/auth";
            $userdata['website_url'] = Utils::getBaseUrl();

            $template = Template::getTemplate('log-in_mail_template');
            $subject = $template->template_subject;
            $message = $template->template_content;

            $subject = $this->replace($userdata, $subject);
            $message = $this->replace($userdata, $message);


            if ($model->save()) {
                $this->SendMail($model->user_email, $model->user_name, $subject, $message);

                echo json_encode(array("error" => FALSE, 'error_code' => "200", "Message" => "User added successfully."));
            } else {

                echo json_encode(array("error" => TRUE, 'error_code' => "201", "Message" => "User Email is already Registor."));
            }
        } else {
            echo json_encode(array("error" => TRUE, 'error_code' => "203", "Message" => "User name & Email are required."));
        }
    }

}
