<?php

class AuthController extends Controller {

    public $user_data;

    protected function beforeAction($event) {
        if ($error = Yii::app()->errorHandler->error) {
            if (Yii::app()->request->isAjaxRequest) {
                // echo $error['message'];die
            } else {
                // $this->render('error', array("error" => $error));
            }
            echo"<pre>";
            print_r($error);
              echo"</pre>";
            die;
        }
        $this->user_data = Yii::app()->session['user_data'];
        $loginmodel = new LoginForm;
        $loginmodel->setConfiguration();

        if (!isset($this->user_data) && empty($this->user_data)) {
            
             if (!in_array(ucfirst(Yii::app()->controller->action->id), array('Index', 'Recover_password','Logout'))) {           
                $this->redirect(Yii::app()->request->baseUrl . '/auth');
            }
        }
        return true;
    }

    /**
     * Declares class-based actions.
     */
    public function actions() {
        return array(
            // captcha action renders the CAPTCHA image displayed on the contact page
            'captcha' => array(
                'class' => 'CCaptchaAction',
                'backColor' => 0xFFFFFF,
            ),
            // page action renders "static" pages stored under 'protected/views/site/pages'
            // They can be accessed via: index.php?r=site/page&view=FileName
            'page' => array(
                'class' => 'CViewAction',
            ),
        );
    }

    /**
     * This is the default 'index' action that is invoked
     * when an action is not explicitly requested by users.
     */
    public function actionIndex() {
        // renders the view file 'protected/views/site/index.php'
        // using the default layout 'protected/views/layouts/main.php'

        if (Yii::app()->session['user_data']) {
            if ($this->user_data['user_last_login_time'] == NULL || $this->user_data['user_last_login_time'] == '0000-00-00 00:00:00') {
                $this->redirect(Yii::app()->request->baseUrl . '/auth/setPassword');
                exit;
            }

            Yii::app()->user->setFlash('Already logged in', 'Already logged in');
            if (isset($this->user_data["user_id"])) {
                $this->redirect(Yii::app()->request->baseUrl . '/dashboard');
            }
            exit;
        }
        $this->actionLogin();
    }

    /**
     * This is the action to handle external exceptions.
     */
    public function actionError() {
        if ($error = Yii::app()->errorHandler->error) {
            if (Yii::app()->request->isAjaxRequest) {
                echo $error['message'];
            } else {
                // $this->render('error', array("error" => $error));
            }
            print_r($error);
            die;
        }
    }

    /**
     * Displays the login page
     */
    public function actionLogin() {

        $model = new LoginForm;
        // if it is ajax validation request
        if (isset($_POST['ajax']) && $_POST['ajax'] === 'login-form') {
            echo CActiveForm::validate($model);
            Yii::app()->end();
        }

        // collect user input data
        if (isset($_POST['LoginForm'])) {
            $model->attributes = $_POST['LoginForm'];
            // validate user input and redirect to the previous page if valid
            if ($model->validate() && $model->login()) {

                $this->user_data = Yii::app()->session['user_data'];
                // if user login first time then it must ask for change the password
                if ($this->user_data['user_last_login_time'] == NULL || $this->user_data['user_last_login_time'] == '0000-00-00 00:00:00') {
                    $model->updateLastLoginTime($this->user_data['user_id']);
                    $this->redirect(Yii::app()->request->baseUrl . '/auth/setPassword');
                } else {
                    $model->updateLastLoginTime($this->user_data['user_id']);
                    $this->redirect(Yii::app()->user->returnUrl);
                }
            }
        }
        $this->layout = 'login_layout';
        // display the login form
        $this->render('new_login', array('model' => $model));
    }

    public function actionRecover_password() {
//print_r($_POST);die;      
        $model = new ForgetPassword;

        // if it is ajax validation request
        //if (isset($_POST['username'])) {
        // print_r($_POST);die;      
        //echo CActiveForm::validate($model);
        //Yii::app()->end();
        //}

        if (isset($_POST['username'])) {

            if ($_POST['username'] == '') {
                echo '3';
                die;
            }


            // echo "asd";
            $model->attributes = $_POST['username'];
            $user = new SuUser;
            // echo "asd";
            // validate user input and redirect to the previous page if valid
            //if ($model->validate()) {
            $postdata = $_POST['username'];
            $user_id = $model->userExist($postdata);
            if ($user_id) {
                $time_diff = '';
                if (Yii::app()->session['pass_reset_time']) {
                    $reset_time = strtotime(Yii::app()->session['pass_reset_time']);
                    $current_time = strtotime(date('Y-m-d H:i:s'));
                    $time_diff = round(($current_time - $reset_time) / 60);
                }
                if ($time_diff > 30 || $time_diff == '') {
                    $msg_id = $model->send_password($user_id['user_id']);

                    $loginmodel = new LoginForm;
                    $loginmodel->UpdateLastLoginOnResetPassword($user_id['user_id']);

                    Yii::app()->session['pass_reset_time'] = date('Y-m-d H:i:s');
                    if ($msg_id) {
                        echo 'Your password was reset and sent to you e-mail and SMS. with message id : ' . $msg_id;
                    } else {

                        echo 0;
                    }

                    die;
                } else {
                    echo 'Your will be able to reset the password only in ' . (30 - $time_diff) . ' minutes.';
                    die;
                }
            } else {
                echo 2;
                die;
            }
            //}
            //echo "qwe";
        }

        $this->layout = 'login_layout';
        // display the login form
        $this->render('recover_password', array('model' => $model, "error" => Yii::app()->user->getFlashes()));
    }

    public function actionSetPassword() {
        $model = new ResetPassword;
        // if it is ajax validation request
        if (isset($_POST['ajax']) && $_POST['ajax'] === 'reset_password') {
            echo CActiveForm::validate($model);
            Yii::app()->end();
        }

        if (isset($_POST['ResetPassword'])) {
            $model->attributes = $_POST['ResetPassword'];

            $loginmodel = new LoginForm;

            // validate user input and redirect to the previous page if valid
            if ($model->validate()) {
                $update_password = $model->reset_password($this->user_data['user_id']);
                if ($update_password == 1) {
                    if ($loginmodel->UpdateLastLoginTime($this->user_data['user_id'])) {
                        $this->redirect(Yii::app()->request->baseUrl . '/auth');
                    } else {
                        $this->redirect(Yii::app()->request->baseUrl . '/auth/setPassword');
                    }
                } else {
                    Yii::app()->user->setFlash('error', "Password could not be reset , please try again !");
                }
            } else {
                Yii::app()->user->setFlash('error', "Password could not be reset , please try again !");
            }
        }
        $this->layout = 'login_layout';
        // display the login form
        // Yii::app()->user->setFlash('error', "Again on same page");
        $this->render('reset_password', array('model' => $model, "error" => Yii::app()->user->getFlashes()));
    }

    public function actionLogout() {

        $loginmodel = new LoginForm;
        $loginmodel->UpdateLastLogoutTime($this->user_data['user_id']);

        unset(Yii::app()->session['user_data']);
        Yii::app()->user->logout();
        $this->redirect(Yii::app()->request->baseUrl . '/auth');
    }

    public function actionDashboard() {

        $this->render('dashboard', $data);
    }

}
