<?php

/**
 * This is the model class for table "users".
 *
 * The followings are the available columns in table 'users':
 * @property integer $user_id
 * @property string $user_name
 * @property string $user_image
 * @property string $user_email
 * @property string $user_password
 * @property integer $user_status
 * @property integer $user_role_type
 * @property integer $user_department_id
 * @property integer $user_created_by_id
 * @property string $user_last_login_time
 * @property string $user_last_logout_time
 * @property string $user_ip_address
 * @property string $created_date
 * @property string $updated_date
 */
class Users extends CActiveRecord {

    /**
     * @return string the associated database table name
     */
    public function tableName() {
        return 'users';
    }

    /**
     * @return array validation rules for model attributes.
     */
    public function rules() {
        // NOTE: you should only define rules for those attributes that
        // will receive user inputs.
        return array(
            array('user_name, user_email, user_password user_role_type ,user_department_id ,user_created_by_id ', 'required'),
            array('user_email', 'email'),
            array('user_email', 'unique'),
            array('user_status, user_role_type, user_department_id, ', 'numerical', 'integerOnly' => true),
            array('user_name, user_image, user_password', 'length', 'max' => 255),
            array('user_email', 'length', 'max' => 55),
            array('user_ip_address', 'length', 'max' => 100),
            array('user_last_login_time, user_last_logout_time, created_date, updated_date', 'safe'),
            // The following rule is used by search().
            // @todo Please remove those attributes that should not be searched.
            array('user_id, user_name, user_image, user_email, user_password, user_status, user_role_type, user_department_id, user_created_by_id, user_last_login_time, user_last_logout_time, user_ip_address, created_date, updated_date', 'safe', 'on' => 'search'),
        );
    }

    /**
     * @return array relational rules.
     */
    public function relations() {
        // NOTE: you may need to adjust the relation name and the related
        // class name for the relations automatically generated below.
        return array(
        );
    }

    /**
     * @return array customized attribute labels (name=>label)
     */
    public function attributeLabels() {
        return array(
            'user_id' => 'ID',
            'user_name' => 'Name',
            'user_image' => 'Profile Photo',
            'user_email' => 'Email ID',
            'user_password' => 'Password',
            'user_status' => 'Status',
            'user_role_type' => 'Role Type',
            'user_department_id' => 'Department',
            'user_created_by_id' => 'Created By',
            'user_last_login_time' => 'Last Login Time',
            'user_last_logout_time' => 'Last Logout Time',
            'user_ip_address' => 'IP Address',
            'created_date' => 'Created Date',
            'updated_date' => 'Updated Date',
        );
    }

    /**
     * Retrieves a list of models based on the current search/filter conditions.
     *
     * Typical usecase:
     * - Initialize the model fields with values from filter form.
     * - Execute this method to get CActiveDataProvider instance which will filter
     * models according to data in model fields.
     * - Pass data provider to CGridView, CListView or any similar widget.
     *
     * @return CActiveDataProvider the data provider that can return the models
     * based on the search/filter conditions.
     */
    public function search($id) {
        // @todo Please modify the following code to remove attributes that should not be searched.

        $criteria = new CDbCriteria;
        $criteria->compare('user_id', $this->user_id);
        $criteria->compare('user_name', $this->user_name, true);
        $criteria->compare('user_image', $this->user_image, true);
        $criteria->compare('user_email', $this->user_email, true);
        $criteria->compare('user_password', $this->user_password, true);
        $criteria->compare('user_status', $this->user_status);
        $criteria->compare('user_role_type<>', $this->user_role_type);
        $criteria->compare('user_department_id', $this->user_department_id);
        $criteria->compare('user_created_by_id', $this->user_created_by_id);
        $criteria->compare('user_last_login_time', $this->user_last_login_time, true);
        $criteria->compare('user_last_logout_time', $this->user_last_logout_time, true);
        $criteria->compare('user_ip_address', $this->user_ip_address, true);
        $criteria->compare('created_date', $this->created_date, true);
        $criteria->compare('updated_date', $this->updated_date, true);
        $criteria->condition = 'user_created_by_id==' . Yii::app()->session['user_data']['user_id'];
        if ($id == 1) {
            $criteria->AddCondition('user_role_type != 5');
        } else {

            $criteria->AddCondition('user_role_type ==5');
        }


        return new CActiveDataProvider($this, array(
            'criteria' => $criteria,
            'pagination' => array(
                'pageSize' => 20,
            ),
        ));
    }

    /**
     * Returns the static model of the specified AR class.
     * Please note that you should have this exact method in all your CActiveRecord descendants!
     * @param string $className active record class name.
     * @return Users the static model class
     */
    public static function model($className = __CLASS__) {
        return parent::model($className);
    }

    public function checkUserRole($roleType) {

        $data = Users::model()->count('user_role_type=' . $roleType);

        return $data;
    }

    public function checkDepartment($id) {
        $data = Users::model()->count('user_department_id=' . $id);
        return $data;
    }

    public static function getUserName($ID) {
        $result = Users::model()->findByPk($ID)->user_name;
        return $result;
    }

}
