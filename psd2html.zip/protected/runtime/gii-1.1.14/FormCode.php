<?php
return array (
  'template' => 'default',
  'viewPath' => 'application.views',
);
