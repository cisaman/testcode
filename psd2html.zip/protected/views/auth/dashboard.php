<div class="page-content">

    <!-- begin PAGE TITLE AREA -->
    <!-- Use this section for each page's title and breadcrumb layout. In this example a date range picker is included within the breadcrumb. -->
    <div class="row">
        <div class="col-lg-12">
            <div class="page-title">
                <h1>Dashboard
                    <small>Content Overview</small>
                </h1>
                <ol class="breadcrumb">
                    <li class="active"><i class="fa fa-dashboard"></i> Dashboard</li>
                    <!--li class="pull-right">
                        <div id="reportrange" class="btn btn-green btn-square date-picker">
                            <i class="fa fa-calendar"></i>
                            <span class="date-range"></span> <i class="fa fa-caret-down"></i>
                        </div>
                    </li-->
                </ol>
            </div>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <!-- end PAGE TITLE AREA -->

    <!-- begin DASHBOARD CIRCLE TILES -->

    <div class="row">
        <div class="col-lg-4">
            <div class="circle-tile">
                <a href="<?php echo Yii::app()->request->baseUrl; ?>/users">
                    <div class="circle-tile-heading dark-blue">
                        <i class="fa fa-users fa-fw fa-3x"></i>
                    </div>
                </a>
                <div class="circle-tile-content dark-blue">
                    <div class="circle-tile-description text-faded">
                        Users
                    </div>
                    <div class="circle-tile-number text-faded">
                        <?php  echo Users::model()->count('user_created_by_id='.Yii::app()->session['user_data']['user_id']); ?>
                        <span id="sparklineA"></span>
                    </div>
                    <a href="<?php echo Yii::app()->request->baseUrl; ?>/users" class="circle-tile-footer">More Info <i class="fa fa-chevron-circle-right"></i></a>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="circle-tile">
                <a href="<?php echo Yii::app()->request->baseUrl; ?>/admin/department">
                    <div class="circle-tile-heading green">
                        <i class="fa fa-briefcase fa-fw fa-3x"></i>
                    </div>
                </a>
                <div class="circle-tile-content green">
                    <div class="circle-tile-description text-faded">
                        Departments
                    </div>
                    <div class="circle-tile-number text-faded">
                           <?php  echo Department::model()->count('department_status=1'); ?>
                    </div>
                    <a href="<?php echo Yii::app()->request->baseUrl; ?>/department" class="circle-tile-footer">More Info <i class="fa fa-chevron-circle-right"></i></a>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="circle-tile">
                <a href="<?php echo Yii::app()->request->baseUrl; ?>/admin/ticket">
                    <div class="circle-tile-heading orange">
                        <i class="fa fa-table fa-fw fa-3x"></i>
                    </div>
                </a>
                <div class="circle-tile-content orange">
                    <div class="circle-tile-description text-faded">
                        Tickets
                    </div>
                    <div class="circle-tile-number text-faded">
                        <?php echo 25; ?>
                    </div>
                    <a href="<?php echo Yii::app()->request->baseUrl; ?>/admin/ticket_list" class="circle-tile-footer">More Info <i class="fa fa-chevron-circle-right"></i></a>
                </div>
            </div>
        </div>
    </div>
    <!-- end DASHBOARD CIRCLE TILES -->


</div>

<!-- PAGE LEVEL PLUGIN SCRIPTS -->

<!-- HubSpot Messenger -->
<script src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/plugins/messenger/messenger.min.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/plugins/messenger/messenger-theme-flat.js"></script>
<!-- Date Range Picker -->
<script src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/plugins/daterangepicker/moment.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/plugins/daterangepicker/daterangepicker.js"></script>

<script src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/plugins/flot/jquery.flot.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/plugins/flot/jquery.flot.resize.js"></script>
<!-- Sparkline Charts -->
<script src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/plugins/sparkline/jquery.sparkline.min.js"></script>
<!-- Moment.js -->
<script src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/plugins/moment/moment.min.js"></script>
<!-- jQuery Vector Map -->
<script src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/plugins/jvectormap/maps/jquery-jvectormap-world-mill-en.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/demo/map-demo-data.js"></script>

<script src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/plugins/datatables/datatables-bs3.js"></script>

<!-- THEME SCRIPTS -->
<script src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/flex.js"></script>

<!--faq search start-->

<script type="text/javascript">

    $(function () {
        $("#dashboardl a").addClass("active");


    });
</script>
