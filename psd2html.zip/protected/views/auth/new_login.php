<div class="portlet portlet-green">
    <div class="portlet-heading login-heading">
        <div class="portlet-title">
            <h4><strong>Login to <?php echo Yii::app()->name; ?>!</strong>
            </h4>
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="portlet-body">
        <?php
        $form = $this->beginWidget('CActiveForm', array(
            'id' => 'login-form',
            'enableClientValidation' => TRUE,
            'clientOptions' => array(
                'validateOnSubmit' => TRUE,
                'validateOnChange' => TRUE
            ),
            'htmlOptions' => array(
                'autocomplete' => 'off',
                'role' => 'form'
            ),
            'focus' => array($model, 'username'),
        ));
        ?>
        <fieldset>            
            <div class="form-group">
                <?php echo $form->textField($model, 'username', array('placeholder' => $model->getAttributeLabel('username'), 'class' => 'form-control')); ?>           
                <?php echo $form->error($model, 'username', array('class' => 'alert-danger')); ?> 
            </div>
            <div class="form-group">
                <?php echo $form->passwordField($model, 'password', array('placeholder' => $model->getAttributeLabel('password'), 'class' => 'form-control')); ?>           
                <?php echo $form->error($model, 'password', array('class' => 'alert-danger')); ?> 
            </div>
            <div class="checkbox">
                <label>
                    <?php echo $form->checkBox($model, 'rememberMe'); ?>
                    <?php echo $form->label($model, 'rememberMe'); ?>
                    <?php echo $form->error($model, 'rememberMe', array('class' => 'alert-danger')); ?>
                </label>
            </div>
            <br>
            <input type="submit" class="btn btn-lg btn-green btn-block" value="Sign In" />
        </fieldset>
        <br>
        <p class="small">
            <a href="<?php echo Yii::app()->request->baseUrl; ?>/auth/recover_password">Forgot your password?</a>
        </p>
        <?php $this->endWidget(); ?>
    </div>
</div>
<script>
//    function validateEmail() {
//        var email = $("#LoginForm_username").val();
//        if (email == "") {
//            $("#LoginForm_username_em_").show();
//            $("#LoginForm_username_em_").html("Email is required.");
//            return false;
//        } else {
//            var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
//            if (!emailReg.test(email)) {
//                $("#LoginForm_username_em_").html("Please enter proper Email ID.").show();
//                // return false;
//            } else {
//                $("#LoginForm_username_em_").html("").hide();
//                return true;
//            }
//        }
//    }
</script>