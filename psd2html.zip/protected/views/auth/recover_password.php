<div class="portlet portlet-green">
    <div class="portlet-heading login-heading">
        <div class="portlet-title">
            <h4><strong>Recover Password</strong>
            </h4>
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="portlet-body">
        <div class="portlet-body">
            <div class="recovery_block">
                
                    

                    <?php
                
                $form = $this->beginWidget('CActiveForm', array(
                    'id' => 'recover_password',
                    'enableClientValidation' => true,
                    'clientOptions' => array(
                        'validateOnSubmit' => true,
                    ),
                ));
                ?>

                <fieldset>
                    <div class="form-group">
                        <?php echo $form->textField($model, 'username', array('placeholder' => 'E-mail', 'class' => 'form-control')); ?>
                        <?php echo $form->error($model, 'username', array('class' => 'alert-danger')); ?>
                    </div>
                    <br>
                    <input type="button" onclick="recovery()" class="btn btn-lg btn-green btn-block" value="Submit" />
                </fieldset>

                <?php $this->endWidget(); ?>
            </div>
            <br>
            <p class="small">
                <a href="<?php echo Yii::app()->request->baseUrl; ?>/auth/login"><span class="fa fa-angle-double-left" > Back to Login</span></a>
            </p>
        </div>
    </div>
    <script type="text/javascript">
        function recovery() {
            //alert('call');
            var username = $('#ForgetPassword_username').val();
             //alert(username);
            $.ajax({
                url: "<?php echo Yii::app()->request->baseUrl; ?>/auth/recover_password",
                type: "POST",
                data: {"username": username},
                success: function(data)
                {
                    if (data == 0) {
                        $(".recovery_block").html('<div class="alert alert-success" ><span  style="font-size:15px;">Your password was reset and sent to you e-mail.</span></div>');
                              
                    }
                    
                    
                   else if (data == 2) {
                        $('.alert-danger').css('display','block');
                        $(".alert-danger").html("<span  style='font-size:15px;'>This email is not exist !</span>");
                    }
                    else if (data == 3) {
                        $('.alert-danger').css('display','block');
                        $(".alert-danger").html("<span  style='font-size:15px;'>Email must be required.</span>");
                    }
                    else
                    {
                        $(".recovery_block").html('<div class="alert alert-success" ><span  style="font-size:15px;">'+data+'</span></div>');
                    }
                
                
            }
            
            });
        }
    </script>